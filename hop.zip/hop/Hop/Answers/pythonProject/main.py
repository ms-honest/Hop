#!/bin/env python


# Hop
# An incomplete game by James Shuttleworth
# Copyright (C) 2006 James Shuttleworth

# csx239@coventry.ac.uk

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

import copy, math, pygame
from pygame.locals import *
import game_functions as game

fgcol = pygame.color.Color('white')  # Foreground colour
bgcol = (100, 100, 100)  # Background colour
screen_size = (500, 500)
play_size = (500, 400)
caption = "Hop it"
frog_img = "frog.png"
thing1_img = "vehicle1.png"
thing2_img = "vehicle2.png"
banner_img = "hop.png"
movespeed = 5


class Floater(pygame.sprite.Sprite):
    """A spaceship"""

    def __init__(self, position, sprite):
        pygame.sprite.Sprite.__init__(self)
        self.image, self.rect = game.load_png(sprite)
        # Move to given position
        self.rect.top = position[1]
        self.rect.left = position[0]

        # keep a note of the screen we're on
        self.area = pygame.Rect((0, 0), play_size)
        # But inflate it to cover a hidden vehicle
        self.area.inflate_ip(200, 0)
        return

    def move(self, x):
        """Move by given distance along the screen """
        # Move our position
        self.rect = self.rect.move(x, 0)

    def outside(self):
        """Test to see if it's off the screen"""
        return not self.area.colliderect(self.rect)


def main():
    pygame.init()
    screen = pygame.display.set_mode(screen_size)
    pygame.display.set_caption(caption)
    clock = pygame.time.Clock()
    # Draw the game background.
    background = (pygame.Surface(screen.get_size())).convert()
    background.fill(bgcol)
    banner, banner_rect = game.load_png(banner_img)

    # A list of rows
    rows = []
    # a list of items for each row
    d = 1
    for ir in range(4):
        r = []
        x = 0
        for ii in range(5):

            if d == -1:
                i = Floater((x, ir * 400 / 4), thing1_img)
            else:
                i = Floater((x, ir * 400 / 4), thing2_img)
            x = x + 150
            r.append(i)
        d = d * -1
        rows.append(r)

    # Game loop
    while True:
        screen.blit(background, (0, 0))

        # Timing - limits to 30 frames per second
        clock.tick(30)
        # Handle events.
        pygame.event.pump()
        for event in pygame.event.get():
            if event.type == QUIT:
                return
            elif event.type == KEYDOWN:
                if event.key == K_UP:
                    speed = [0, -1]
                    pass
                elif event.key == K_DOWN:
                    speed = [0, 1]
                    pass

                elif event.key == K_LEFT:
                    speed = [-1, 0]
                    pass

                elif event.key == K_RIGHT:
                    speed = [1, 0]
                    pass

        # Move player
        # ????

        # move the vehicles

        for r in rows:
            for i in r:
                i.move(d)
                # If it's off the screen...
                if i.outside():
                    # Move it back to the start
                    i.move(700 * d * -1)

            d = d * -1

        # Draw the player
        # ???
        # Draw the vehicles
        for r in rows:
            for i in r:
                sprite = pygame.sprite.RenderPlain(i)
                sprite.draw(screen)

        # Draw the banner
        screen.blit(banner, (0, 400))

        # Have we been run over?

        pygame.display.flip()


if __name__ == '__main__':
    main()