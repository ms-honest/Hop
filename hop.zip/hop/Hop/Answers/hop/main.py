import random


def game(m):
    ESC = '\x1b'
    print(ESC + '[33m' + '   multiplier of numbers-->'+str(m))
    r = int(rand(m))
    print(ESC + '[36m' +'    '+str(r))
    players_turn = True
    r += 1
    while True:
        if players_turn:
            number = input()
            if r % m == 0:
                if number.lower() != 'hop':
                    print('lose')
                    return
            elif int(number) != r:
                print('lose')
                return
            players_turn = False

        else:
            if r % m == 0:
                print("Hop")
            else:
                print(r)
            players_turn = True
        r += 1



def rand(m):
    randi = int(random.randint(1 , 100))
    if randi % m == 0:
        rand(m)
    else:
        return randi


def start():
    ESC = '\x1b'
    print(ESC + '[36m' + '  •───────•°•HOP•°•───────•')
    print(ESC + '[33m' + '    enter the coefficient:')
    coe = input(ESC + '[36m' + '    >>')
    if int(coe) == 0 or int(coe) == 1:
        print(ESC + '[36m' + 'the number should be bigger then 1')
        start()
    else:
        game(int(coe))


if __name__ == '__main__':
    start()
